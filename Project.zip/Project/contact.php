<!DOCTYPE html>
<html lang="en">
    <head>
        <title>SIT Hotel</title>
        <?php
        // INCLUDE UR OWN HEAD.PHP HERE, CSS CAN BE DIFFERENT
            include "inc/head.inc.php";
        ?>
    </head>
    
    <body>
        <?php
            include "inc/nav.inc.php";
        ?>
        <main>
        <!-- Enter Code Here -->


            <?php
                include "inc/footer.inc.php";
            ?>
        </main>
    </body>
</html>