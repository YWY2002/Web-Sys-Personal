<header class="jumbotron text-center text-light bg-dark rounded-0">
    <h1 class="display-4">Welcome to World of Pets!</h1>
    <h2>Home of Singapore's Pet Lovers</h2>
</header>